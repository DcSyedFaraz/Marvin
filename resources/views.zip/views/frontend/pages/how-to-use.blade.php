@extends('frontend.layouts.master')

@section('content')
<section class="aboutus">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="about-heading">How To Use</h2>
                </div>
            </div>
        </div>
    </section>
@endsection